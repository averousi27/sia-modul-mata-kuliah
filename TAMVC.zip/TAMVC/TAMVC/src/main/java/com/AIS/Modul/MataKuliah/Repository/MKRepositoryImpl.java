package com.AIS.Modul.MataKuliah.Repository;

public class MKRepositoryImpl {

}
