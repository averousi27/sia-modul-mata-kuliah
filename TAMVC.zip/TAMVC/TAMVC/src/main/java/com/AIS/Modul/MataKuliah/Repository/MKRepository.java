package com.AIS.Modul.MataKuliah.Repository;

public interface MKRepository {

}
