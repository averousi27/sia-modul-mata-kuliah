package com.AIS.Modul.MataKuliah.Controller;

public class SatManController {

}
